<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Contracts\JobListRepositoryInterface;

class JobListController extends Controller
{
    // repository
    protected $re;

    public function __construct(JobListRepositoryInterface $re)
    {
        $this->re = $re;
    }

    private function jobList($jobs)
    {
        $re = $this->re;
        $careers = $re->careers();
        $salaries = $re->salaries();
        $experiences = $re->experiences();
        $provinces = $re->provinces();
        return view('job_list', compact('careers', 'salaries', 'experiences', 'provinces', 'jobs'));
    }

    public function manage()
    {
        $re = $this->re;
        $manage = $re->manage();
        return $this->jobList($manage);
    }

    public function specialize()
    {
        $re = $this->re;
        $specialize = $re->specialize();
        return $this->jobList($specialize);
    }

    public function labor()
    {
        $re = $this->re;
        $labor = $re->labor();
        return $this->jobList($labor);
    }

    public function student()
    {
        $re = $this->re;
        $student = $re->student();
        return $this->jobList($student);
    }

    public function searchAjax()
    {
        echo 's';
    }
}
