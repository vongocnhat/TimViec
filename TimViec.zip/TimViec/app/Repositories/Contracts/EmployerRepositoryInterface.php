<?php

namespace App\Repositories\Contracts;

interface EmployerRepositoryInterface extends BaseRepositoryInterface
{
    
}