<?php

namespace App\Repositories\Contracts;

interface HomeRepositoryInterface
{
    
}