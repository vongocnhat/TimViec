<?php

namespace App\Repositories\Contracts;

interface EmployeeRepositoryInterface extends BaseRepositoryInterface
{
    
}