<?php
return [
    'employer' => 'employer',
    'title' => 'Manage Employer',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'password' => 'Password',
    'company_name' => 'Company Name',
    'company_size' => 'Company Size',
    'landline_phone' => 'Landline Phone',
    'about_company' => 'About Company',
    'province' => 'Province',
    'district' => 'District',
    'ward' => 'Ward',
    'address' => 'Address',
    'website' => 'Website',
];