<?php
return [
    'employer' => 'Nhà Tuyển Dụng',
    'title' => 'Quản Lý Nhà Tuyển Dụng',
    'first_name' => 'Họ',
    'last_name' => 'Tên',
    'email' => 'Email',
    'phone' => 'Số Điện Thoại',
    'password' => 'Mật Khẩu',
    'company_name' => 'Tên Công Ty',
    'company_size' => 'Kích Thước Công Ty',
    'landline_phone' => 'Điện Thoại Cố Định',
    'about_company' => 'Giới Thiệu Về Công Ty',
    'province' => 'Thành Phố',
    'district' => 'Quận',
    'ward' => 'Phường',
    'address' => 'Địa Chỉ',
    'website' => 'Website',
];