<?php
return [
    'employee' => 'Nhân Viên',
    'title' => 'Quản Lý Nhân Viên',
    'first_name' => 'Họ',
    'last_name' => 'Tên',
    'email' => 'Email',
    'phone' => 'Số Điện Thoại',
    'password' => 'Mật Khẩu',
    'birthday' => 'Ngày Sinh',
    'province' => 'Thành Phố',
    'district' => 'Quận',
    'ward' => 'Phường',
    'address' => 'Địa Chỉ',
    'gender' => 'Giới Tính',
    'married' => 'Tình Trạng Hôn Nhân',
    'married_true' => 'Đã Kết Hôn',
    'married_false' => 'Chưa Kết Hôn',
];
